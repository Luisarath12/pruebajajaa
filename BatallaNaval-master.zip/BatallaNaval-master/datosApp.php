<?php
    $nombre_app = "Batalla Naval";
    $version_app = "0.1";
?>