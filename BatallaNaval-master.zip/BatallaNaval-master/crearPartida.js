/*globals $:false */
/* jshint browser: true */

$(document).ready(
    function(){
        $("#bt_dialogo_aceptar").click(
            function(){
                $("#crear_partida").submit();
            }
        );
        
    }
);