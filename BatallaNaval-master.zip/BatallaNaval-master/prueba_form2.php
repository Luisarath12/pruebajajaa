<html>
    <head>
        <meta http-equiv='Content-type' content='text/html;charset=UTF-8'>
        <script type='text/javascript' src='jquery.js'></script>
    </head>
    <body>
        <form id="previo" action="login.php" method="post">
            
            <label for="nombre_u">Usuario</label><br /> 
            <input id="nombre_u" name="nombre_u" type="text" /> <br />
            
            <label for="contrasenia">Contraseña</label><br /> 
            <input id="contrasenia" name="contrasenia" type="password" /> <br />
            <input type="submit" value="Enviar">
        </form>
        
        <script>
            
        </script>
        
    </body>
</html>